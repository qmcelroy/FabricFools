"use strict";

//Declare List Of Shirt objects

var shirt1 = {color: "Blue", brand:"Polo", style: "t-shirt", usage: 3200, purchaseDate: "1/1/19",
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt2 = {color: "White", brand:"Cowboy Bebop", style: "t-shirt", usage: 5400, purchaseDate: "2/1/19",
 pic: "cowboy.jpg"};
var shirt3 = {color: "Grey", brand:"Pug", style: "t-shirt", usage: 7104, purchaseDate: "1/1/18",
 pic: "holy.jpg"};
var shirt4 = {color: "Dark Grey", brand:"CIS430", style: "t-shirt", usage: 2453, purchaseDate: "4/30/19",
 pic: "geek.png"};
 var shirt5 = {color: "Dark Grey", brand:"Cinco", style: "t-shirt", usage: 500, purchaseDate: "5/05/18",
 pic: "meow.png"};
 var shirt6 = {color: "Blue", brand:"Nike", style: "t-shirt", usage: 5000, purchaseDate: "1/1/19",
 pic: "touchdown.jpg"};
var shirt7 = {color: "Grey", brand:"Lululemon", style: "tank", usage: 502, purchaseDate: "1/1/19",
 pic: "boxer.png"};
 var shirt8 = {color: "red", brand:"nike", style: "tshirt", usage: 8200, purchaseDate: "1/1/19",
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt9 = {color: "blue", brand:"polo", style: "tshirt", usage: 4400, purchaseDate: "1/1/19",
 pic: "cowboy.jpg"};
var shirt10 = {color: "green", brand:"nike", style: "tshirt", usage: 10104, purchaseDate: 1/1/19,
 pic: "holy.jpg"};
var shirt11 = {color: "green", brand:"nike", style: "tshirt", usage: 2153, purchaseDate: 1/1/19,
 pic: "geek.png"};
 var shirt12 = {color: "green", brand:"nike", style: "tshirt", usage: 100, purchaseDate: 1/1/19,
 pic: "meow.png"};
 var shirt13 = {color: "green", brand:"nike", style: "tshirt", usage: 0, purchaseDate: 1/1/19,
 pic: "touchdown.jpg"};
var shirt14 = {color: "green", brand:"nike", style: "tshirt", usage: 511, purchaseDate: 1/1/19,
 pic: "boxer.png"};
 

//Create shirts Array
var shirts = [shirt1,shirt2,shirt3,shirt4,shirt5,shirt6,shirt7]


// tabs and camera plugin logic




/*===========================*/
/* put global variables here */
/*===========================*/

var takePhotoButton
var photoStatus    
var photoImage     
var cameraOptions  
var imageFilename
var options 
var homeTab  
var filterTab    

/* wait until all phonegap/cordova is loaded then call onDeviceReady*/
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady(){

    StatusBar.overlaysWebView(false); // force ios to show status bar
    navigator.splashscreen.show();
	showHomeTab();



    takePhotoButton = document.getElementById('takePhotoButtonId')
    photoStatus     = document.getElementById('photoStatusId')
    photoImage      = document.getElementById('photoImageId')
    imageFilename   = document.getElementById('imageFilenameId')
    cameraOptions   = document.getElementById('cameraOptionsId')
    filterTab       = document.getElementById('filterTab')
    homeTab         = document.getElementById("homeTab")

    options         = {
            quality: 40,
            destinationType:    Camera.DestinationType.FILE_URI,
            sourceType:         Camera.PictureSourceType.CAMERA,
            correctOrientation: true, 
            mediaType:          Camera.MediaType.PICTURE,
            encodingType:       Camera.EncodingType.JPEG,
            cameraDirection:    Camera.Direction.BACK,
            targetWidth:        300,
            targetHeight:       400        
    }

    cameraOptions.innerHTML = JSON.stringify(options, null, 2)
    filterTab.style.display = "none";
}

function takePhoto() {
    navigator.camera.getPicture(photoSuccess, photoError, options)
}

function photoSuccess(imageURI) {
    photoStatus.innerHTML = "Success!";
    imageFilename.innerHTML = imageURI;
    photoImage.src = imageURI
}

function photoError(errorMessage) {
    photoStatus.innerHTML = "Failed: " + errorMessage;
    imageFilename.innerHTML = "";
}
//End of Camera Plug-ins/Method


function MostWorn() {
   clearPage();
    sortArrayHigh();
    createList();
    
}
function clearPage() {
    var parent = document.getElementById("body");
    var child = document.getElementById("main");
    parent.removeChild(child);
}

function LeastWorn() {
    clearPage();
    sortArrayLow();
    createList();
    
}

//Main Function thats called when shirts.html
//loads creates shirts page and details page
//Method Create divs based on shirts[]
function createList() {
    

    var outputMain = document.createElement("main");
    outputMain.id="main";
    document.body.appendChild(outputMain);

    var topDiv = document.createElement("div");
    topDiv.id="topDiv";

    var sortDivRight = document.createElement("div");
    sortDivRight.innerHTML = "Most Worn";
    sortDivRight.className="sortingDivs";
    sortDivRight.onclick = function(){MostWorn();}

    outputMain.appendChild(sortDivRight);

    var sortDivLeft = document.createElement("div");
    sortDivLeft.innerHTML = "Least Worn";
    sortDivLeft.className="sortingDivs";
    sortDivLeft.onclick = function(){LeastWorn();}


    outputMain.appendChild(sortDivLeft);

   
    var rowDiv = document.createElement("div");
    rowDiv.className="rowDiv";
    rowDiv.id="mainDiv"
    outputMain.appendChild(rowDiv);

    
    for (var i = 0; i < shirts.length; i++) {
        
        var div = document.createElement("div");

        div.className="overRightDiv";


        //On Click for Div generates new details page in same HTML

        div.onclick = function() {
                  

            clearPage();

                
            for (var i = 0; i < shirts.length; i++) {
                if(this.firstChild.src.includes(shirts[i].pic))
                {
                    var detailItem = shirts[i];
                }
            }
                

            var detailMain = document.createElement("main")
            detailMain.id="detailMain";
            var detailDiv = document.createElement("div");
            detailDiv.className="detailDiv";


            var picDiv = document.createElement("div");
            var infoDiv = document.createElement("div");
            infoDiv.id="lInfoDiv";
            picDiv.id="rInfoDiv";

            var detailImg = document.createElement("img");
            detailImg.id="detailImg";
            detailImg.src = detailItem.pic;
            picDiv.appendChild(detailImg);

            var infoLine1 = document.createElement("h2");
            var infoLine2 = document.createElement("h2");
            var infoLine3 = document.createElement("h2");
            var infoLine4 = document.createElement("h2");
            var infoLine5 = document.createElement("h2");


            var br4 = document.createElement("br");


            infoLine1.innerHTML ="Brand: " +detailItem.brand;
            infoLine2.innerHTML ="Color: " +detailItem.color;
            infoLine3.innerHTML ="Style: " +detailItem.style;
            infoLine4.innerHTML ="Purchase Date: " +detailItem.purchaseDate;
            infoLine5.innerHTML ="Time On: " +ConvertUsage(detailItem.usage);


            infoDiv.appendChild(infoLine1);
            infoDiv.appendChild(br);
            infoDiv.appendChild(infoLine2);
            infoDiv.appendChild(br2);
            infoDiv.appendChild(infoLine3);
            infoDiv.appendChild(br3);
            infoDiv.appendChild(infoLine4);
            infoDiv.appendChild(br4);
            infoDiv.appendChild(infoLine5);

            var similarH2 = document.createElement("h2");
            similarH2.innerHTML = "Shop Similar Items";


            var Slider = document.createElement("div");
             Slider.id="Slider";

            for (var j = 0; j < 6; j++) {
                    //debugger
                var slideDiv = document.createElement("div");
                slideDiv.className = "slideDiv";
                var slideTitle = document.createElement("h2");
                var slideImg = document.createElement("img");
                var slideBr = document.createElement("br");
                slideImg.className = "slideImg"; 

                slideImg.src = shirts[j].pic;

                slideTitle.innerHTML = "Shirt";


                slideDiv.appendChild(slideTitle);
                slideDiv.appendChild(slideBr);
                slideDiv.appendChild(slideImg);
                Slider.appendChild(slideDiv);
            }
                
                
            var itemDetails = document.createElement("div");
            itemDetails.id="itemDetails";
            itemDetails.innerHTML = "Item Details";

            var sellDiv = document.createElement("div");
            sellDiv.id="sellDiv";
            sellDiv.innerHTML = "Sell Item!";

            sellDiv.onclick = function (){alert("Item Up Sale!")}


            detailMain.appendChild(itemDetails);


            detailDiv.appendChild(picDiv);
            detailDiv.appendChild(infoDiv);
            detailDiv.appendChild(similarH2);
            detailDiv.appendChild(Slider);
            detailDiv.appendChild(sellDiv);

            detailMain.appendChild(detailDiv);


            document.body.appendChild(detailMain);


                
            nav.onclick = function(){location.reload();}
  
        }

        var brandName = document.createElement("h2");
        var clothColor = document.createElement("h2");
        var usagePerItem = document.createElement("h2")
           
        var br = document.createElement("br");
        var br2 = document.createElement("br");
        var br3 = document.createElement("br");

        clothColor.innerHTML = "Color: " + shirts[i].color;
        brandName.innerHTML = "Brand: " + shirts[i].brand;
            
        usagePerItem.innerHTML = "Time On: " + ConvertUsage(shirts[i].usage);
           
        var pic = document.createElement("img")
        pic.className="rowImg"
        pic.src = shirts[i].pic;
             
        div.appendChild(pic);
        div.appendChild(br);
        div.appendChild(clothColor);
        div.appendChild(br2)
        div.appendChild(brandName);
        div.appendChild(br3);
        div.appendChild(usagePerItem);


        rowDiv.appendChild(div);
            
    }   
}

function goBack() {
  window.history.back();
}
 function ConvertUsage(num){
    let h = Math.floor(num/60);
    let m = num%60;
    let d = Math.floor(h/24);
    h = h%24;                     
    return(d +" days " + h +" hours " + m + " minutes ").toString();
}
function sortArrayHigh(){
    shirts.sort(function(a, b){
    return b.usage-a.usage})
}
function sortArrayLow(){
    shirts.sort(function(a, b){
    return a.usage-b.usage})
}
