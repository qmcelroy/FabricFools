// put your javascript code here, make sure you reference this with a script 
// at the just before the closing body tag:
// 
//     <script type="text/javascript" src="js/index.js"></script>


"use strict";

var mysqlServerElem;
var mysqlUsernameElem;
var mysqlPasswordElem;
var mysqlDatabaseElem;

var mysqlServerSetting;
var mysqlUsernameSetting;
var mysqlPasswordSetting;
var mysqlDatabaseSetting;

document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady() {

    StatusBar.overlaysWebView(false); // force ios to show status bar
    
    mysqlServerElem   = document.getElementById('mysqlServerId');
    mysqlUsernameElem = document.getElementById('mysqlUsernameId');    
    mysqlPasswordElem = document.getElementById('mysqlPasswordId');
    mysqlDatabaseElem = document.getElementById('mysqlDatabaseId');

    loadSettings();
	showHomeTab();
}

function showHomeTab() {
	document.getElementById('home').click();
}

function showTab(event, tabName) {
    // Declare all variables
    var i, tabContentElems, tabLinkElems;

    // Get all elements with class="tabContent" and hide them
    tabContentElems = document.getElementsByClassName("tabContent");
    for (i = 0; i < tabContentElems.length; i++) {
        tabContentElems[i].style.display = "none";
    }

    // Get all elements with class="tabLink" and remove the class "active"
    tabLinkElems = document.getElementsByClassName("tabLink");
    for (i = 0; i < tabLinkElems.length; i++) {
        tabLinkElems[i].className = 
        	tabLinkElems[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the link
    document.getElementById(tabName).style.display = "block";
    event.currentTarget.className += " active";
}

function loadSettings() {
    mysqlServerElem.value   = localStorage.mysqlServerSetting   || 'sql.wpc-is.online';
    mysqlUsernameElem.value = localStorage.mysqlUsernameSetting || 'username';
    mysqlPasswordElem.value = localStorage.mysqlPasswordSetting || 'demo12345';
    mysqlDatabaseElem.value = localStorage.mysqlDatabaseSetting || 'BabyNames';
}

function clearSettings() {
    localStorage.clear(); /* deletes all local storage elements */
    loadSettings();
}

function saveSettings() {
    localStorage.mysqlServerSetting   = mysqlServerElem.value;  
    localStorage.mysqlUsernameSetting = mysqlUsernameElem.value;
    localStorage.mysqlPasswordSetting = mysqlPasswordElem.value;
    localStorage.mysqlDatabaseSetting = mysqlDatabaseElem.value;
}

function testConnection() {
		MySql.Execute(
			mysqlServerElem.value,			// mySQL server
			mysqlUsernameElem.value, 		// login name
			mysqlPasswordElem.value, 		// login password
			mysqlDatabaseElem.value, 		// database to use
											// SQL query string
			"SHOW TABLES FROM " + mysqlDatabaseElem.value + ";",
	        function (data) {
	        	processTestResult(data);
	    	}
	    );
}

function processTestResult(queryReturned) {
    if (!queryReturned.Success) {
        document.getElementById("mysqlConnectionStatus").innerHTML = queryReturned.Error;
    } else {
        document.getElementById("mysqlConnectionStatus").innerHTML = "Good Settings!";
    }
}

function doQuery() {
    MySql.Execute(
        mysqlServerElem.value,			// mySQL server
        mysqlUsernameElem.value, 		// login name
        mysqlPasswordElem.value, 		// login password
        mysqlDatabaseElem.value, 		// database to use
                                        // SQL query string
        "SELECT 											\
            state, year, name, number 						\
            FROM 											\
            NamesNumberByStateYear 							\
            WHERE 											\
            state = 'AZ' AND sex = 'boy' AND year = '1964' 	\
            ORDER BY number DESC 							\
            LIMIT 5;",
        function (data) {
            processQueryResult(data);
        }
    );
}

function processQueryResult(queryReturned) {
    if (!queryReturned.Success) {
        alert(queryReturned.Error)
    } else {

        var queryOut, table, tableBody, tableHeader, tableRow;
        var rows = queryReturned.length;

        queryOut    = document.getElementById("queryOutput");
        table  	  	= document.createElement("table");
        tableBody 	= document.createElement("tbody");
        tableHeader = document.createElement("tr");

        var keys = Object.keys(queryReturned.Result[0]);
        for (var i=0; i<keys.length; i++) {
            var cell     = document.createElement("th");
            var cellText = document.createTextNode(keys[i]);
            cell.appendChild(cellText);
            tableHeader.appendChild(cell);
        }

        tableBody.appendChild(tableHeader);

        for (var i=0; i<queryReturned.Result.length; i++) {
            var tableRow = document.createElement("tr");

            for (var j=0; j<Object.keys(queryReturned.Result[i]).length; j++) {
                var cell 	 = document.createElement("td");
                var cellText = document.createTextNode(Object.values(queryReturned.Result[i])[j]);
                cell.appendChild(cellText);
                tableRow.appendChild(cell);
            }

            tableBody.appendChild(tableRow);
        }
        table.appendChild(tableBody);
        table.setAttribute("border", "2");
        queryOut.appendChild(table);
    }
}