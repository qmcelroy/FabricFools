var shirt1 = {color: "red", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19, pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt2 = {color: "blue", brand:"polo", style: "tshirt", usage: 500, purchaseDate: 1/1/19, pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt3 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19, pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};

var shirts = [shirt1,shirt2,shirt3];

var rows = 0;

var n = 0;

function NumberOfRows(shirtArray) {
	n = shirtArray.length + 1;
	if (shirtArray.length % 3 === 0) {
		rows = shirts.length/3;
	}
	if(n % 3 === 0){
		rows = n/3;
	}
	else if((n+1) % 3 === 0){
		rows = (n+1)/3;
	}
	return rows;

}


function createList() {
	var outputMain = document.createElement("main")
	document.body.appendChild(outputMain);
	//outputMain.className="tab";
	NumberOfRows(shirts);

	for (var i = 0; i <= rows; i++) {
		var rowDiv = document.createElement("div");
		rowDiv.className="rowDiv";
		outputMain.appendChild(rowDiv);

	
		for (var i = 0; i <= shirts.length; i++) {
		
			var div = document.createElement("div");
			div.className="innerDiv";
			var brandName = document.createElement("h2");
			var clothColor = document.createElement("h2");
			var br = document.createElement("br");
			var br2 = document.createElement("br");

			clothColor.innerHTML = "Color: " + shirts[i].color;
			brandName.innerHTML = "Brand: " + shirts[i].brand;
			// div.className="container"
			var pic = document.createElement("img")
			pic.className="rowImg"
			pic.src = "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"
  			//div.innerHTML = shirts[i].brand + " " + shirts[i].color; 
  			div.appendChild(pic);
  			div.appendChild(br2);
  			div.appendChild(clothColor);
  			div.appendChild(br)
  			div.appendChild(brandName);



  			rowDiv.appendChild(div);

		}
	}

}