var shirt1 = {color: "red", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt2 = {color: "blue", brand:"polo", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt3 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt4 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt5 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt6 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt7 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt8 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt9 = {color: "red", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt10 = {color: "blue", brand:"polo", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt11 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt12 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt13 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt14 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt15 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt16 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt17 = {color: "red", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt18 = {color: "blue", brand:"polo", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt19 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt20 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt21 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt22 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt23 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt24 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};

var shirts = [shirt1,shirt2,shirt3,shirt4,shirt5,


shirt6,shirt7,
shirt8,shirt9,shirt10,shirt11,shirt12,shirt13,shirt14,shirt15,
shirt16,shirt17,shirt18,shirt19,shirt20,shirt21,shirt22,shirt23,shirt24];

var rows = 0;

var n = 0;

function NumberOfRows(shirtArray) {
	n = shirtArray.length + 1;
	if (shirtArray.length % 3 === 0) {
		rows = shirts.length/3;
	}
	if(n % 3 === 0){
		rows = n/3;
	}
	else if((n+1) % 3 === 0){
		rows = (n+1)/3;
	}
	return rows;

}


function createList() {
	var outputMain = document.createElement("main")
	document.body.appendChild(outputMain);
	//outputMain.className="tab";

	NumberOfRows(shirts);

	for (var j = 0; j <= rows; j++) {
		var rowDiv = document.createElement("div");
		rowDiv.className="rowDiv";
		outputMain.appendChild(rowDiv);

	
		for (var i = 0; i <= shirts.length; i++) {
		
			var div = document.createElement("div");
			div.className="overRightDiv";
			var brandName = document.createElement("h2");
			var clothColor = document.createElement("h2");
			var br = document.createElement("br");
			var br2 = document.createElement("br");

			clothColor.innerHTML = "Color: " + shirts[i].color;
			brandName.innerHTML = "Brand: " + shirts[i].brand;
			// div.className="container"
			var pic = document.createElement("img")
			pic.className="rowImg"
			pic.src = "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"
  			//div.innerHTML = shirts[i].brand + " " + shirts[i].color; 
  			div.appendChild(pic);
  			div.appendChild(br2);
  			div.appendChild(clothColor);
  			div.appendChild(br)
  			div.appendChild(brandName);



  			rowDiv.appendChild(div);

		}
	}

}


function goBack() {
  window.history.back();
}