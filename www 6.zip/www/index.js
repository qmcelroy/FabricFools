"use strict";

var shirt1 = {color: "red", brand:"nike", style: "tshirt", usage: 3200, purchaseDate: "1/1/19",
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt2 = {color: "blue", brand:"polo", style: "tshirt", usage: 5400, purchaseDate: "1/1/19",
 pic: "cowboy.jpg"};
var shirt3 = {color: "green", brand:"nike", style: "tshirt", usage: 7104, purchaseDate: "1/1/19",
 pic: "holy.jpg"};
var shirt4 = {color: "green", brand:"nike", style: "tshirt", usage: 2453, purchaseDate: "1/1/19",
 pic: "geek.png"};
 var shirt5 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: "1/1/19",
 pic: "meow.png"};
 var shirt6 = {color: "green", brand:"nike", style: "tshirt", usage: 5000, purchaseDate: "1/1/19",
 pic: "touchdown.jpg"};
var shirt7 = {color: "green", brand:"nike", style: "tshirt", usage: 502, purchaseDate: "1/1/19",
 pic: "boxer.png"};
 var shirt8 = {color: "red", brand:"nike", style: "tshirt", usage: 8200, purchaseDate: "1/1/19",
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt9 = {color: "blue", brand:"polo", style: "tshirt", usage: 4400, purchaseDate: "1/1/19",
 pic: "cowboy.jpg"};
var shirt10 = {color: "green", brand:"nike", style: "tshirt", usage: 10104, purchaseDate: 1/1/19,
 pic: "holy.jpg"};
var shirt11 = {color: "green", brand:"nike", style: "tshirt", usage: 2153, purchaseDate: 1/1/19,
 pic: "geek.png"};
 var shirt12 = {color: "green", brand:"nike", style: "tshirt", usage: 100, purchaseDate: 1/1/19,
 pic: "meow.png"};
 var shirt13 = {color: "green", brand:"nike", style: "tshirt", usage: 0, purchaseDate: 1/1/19,
 pic: "touchdown.jpg"};
var shirt14 = {color: "green", brand:"nike", style: "tshirt", usage: 511, purchaseDate: 1/1/19,
 pic: "boxer.png"};
 

var shirts = [shirt1,shirt2,shirt3,shirt4,shirt5,shirt6,shirt7,shirt8,shirt9]


var mainDetails = document.getElementById('mainDetails');

var item = document.createElement("div");







// tabs and camera plugin logic




/*===========================*/
/* put global variables here */
/*===========================*/

var takePhotoButton
var photoStatus    
var photoImage     
var cameraOptions  
var imageFilename
var options 
var homeTab  
var filterTab    

/* wait until all phonegap/cordova is loaded then call onDeviceReady*/
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady(){

    StatusBar.overlaysWebView(false); // force ios to show status bar
    navigator.splashscreen.show();
	showHomeTab();



    takePhotoButton = document.getElementById('takePhotoButtonId')
    photoStatus     = document.getElementById('photoStatusId')
    photoImage      = document.getElementById('photoImageId')
    imageFilename   = document.getElementById('imageFilenameId')
    cameraOptions   = document.getElementById('cameraOptionsId')
    filterTab       = document.getElementById('filterTab')
    homeTab         = document.getElementById("homeTab")

    options         = {
            quality: 40,
            destinationType:    Camera.DestinationType.FILE_URI,
            sourceType:         Camera.PictureSourceType.CAMERA,
            correctOrientation: true, 
            mediaType:          Camera.MediaType.PICTURE,
            encodingType:       Camera.EncodingType.JPEG,
            cameraDirection:    Camera.Direction.BACK,
            targetWidth:        300,
            targetHeight:       400        
    }

    cameraOptions.innerHTML = JSON.stringify(options, null, 2)
    filterTab.style.display = "none";
}

function takePhoto() {
    navigator.camera.getPicture(photoSuccess, photoError, options)
}

function photoSuccess(imageURI) {
    photoStatus.innerHTML = "Success!";
    imageFilename.innerHTML = imageURI;
    photoImage.src = imageURI
}

function photoError(errorMessage) {
    photoStatus.innerHTML = "Failed: " + errorMessage;
    imageFilename.innerHTML = "";
}

function MostWorn() {
   clearPage();
    sortArrayHigh();
    createList();
    
}
function clearPage() {
    var parent = document.getElementById("body");
    var child = document.getElementById("main");
    parent.removeChild(child);
}

function LeastWorn() {
    clearPage();
    sortArrayLow();
    createList();
    
}


function createList() {
    //debugger
    //sortArray();

    var outputMain = document.createElement("main");
    outputMain.id="main";
    document.body.appendChild(outputMain);

    var topDiv = document.createElement("div");
    topDiv.id="topDiv";

    var sortDivRight = document.createElement("div");
    sortDivRight.innerHTML = "Most Worn";
    sortDivRight.className="sortingDivs";
    sortDivRight.onclick = function(){MostWorn();}

    outputMain.appendChild(sortDivRight);

    var sortDivLeft = document.createElement("div");
    sortDivLeft.innerHTML = "Least Worn";
    sortDivLeft.className="sortingDivs";
    sortDivLeft.onclick = function(){LeastWorn();}


    outputMain.appendChild(sortDivLeft);


   
        var rowDiv = document.createElement("div");
        rowDiv.className="rowDiv";
        rowDiv.id="mainDiv"
        outputMain.appendChild(rowDiv);

    
        for (var i = 0; i < shirts.length; i++) {
        
            var div = document.createElement("div");

            div.className="overRightDiv";


            //debugger
            div.onclick = function() {
                
                //location.assign("details.html");

                clearPage();

                //DivDetails();
                for (var i = 0; i < shirts.length; i++) {
                    if(this.firstChild.src.includes(shirts[i].pic))
                    {
                        var detailItem = shirts[i];
                    }
                 }
                

                var detailMain = document.createElement("main")
                var picDiv = document.createElement("div");
                var infoDiv = document.createElement("div");
                infoDiv.id="lInfoDiv";
                picDiv.id="rInfoDiv";

                var detailImg = document.createElement("img");
                detailImg.id="detailImg";
                detailImg.src = detailItem.pic;
                picDiv.appendChild(detailImg);

                var infoLine1 = document.createElement("h2");
                var infoLine2 = document.createElement("h2");
                var infoLine3 = document.createElement("h2");
                var infoLine4 = document.createElement("h2");
                var infoLine5 = document.createElement("h2");


                var br4 = document.createElement("br");


                infoLine1.innerHTML ="Brand: " +detailItem.brand;
                infoLine2.innerHTML ="Color: " +detailItem.color;
                infoLine3.innerHTML ="Style: " +detailItem.style;
                infoLine4.innerHTML ="Purchase Date: " +detailItem.purchaseDate;
                infoLine5.innerHTML ="Time On: " +ConvertUsage(detailItem.usage);


                infoDiv.appendChild(infoLine1);
                infoDiv.appendChild(br);
                infoDiv.appendChild(infoLine2);
                infoDiv.appendChild(br2);
                infoDiv.appendChild(infoLine3);
                infoDiv.appendChild(br3);
                infoDiv.appendChild(infoLine4);
                infoDiv.appendChild(br4);
                infoDiv.appendChild(infoLine5);

                var similarH2 = document.createElement("h2");
                similarH2.innerHTML = "Shop Similar Items";







                var Slider = document.createElement("div");
                Slider.id="Slider";

                for (var j = 0; j < 6; j++) {
                    //debugger
                    var slideDiv = document.createElement("div");
                    slideDiv.className = "slideDiv";
                    var slideTitle = document.createElement("h2");
                    var slideImg = document.createElement("img");
                    var slideBr = document.createElement("br");
                    slideImg.className = "slideImg"; 

                    slideImg.src = shirts[j].pic;

                    slideTitle.innerHTML = "Shirt";


                    slideDiv.appendChild(slideTitle);
                    slideDiv.appendChild(slideBr);
                    slideDiv.appendChild(slideImg);
                    Slider.appendChild(slideDiv);
                }
                
                
                //infoDiv.appendChild(detailString);
                detailMain.appendChild(picDiv);
                detailMain.appendChild(infoDiv);
                detailMain.appendChild(similarH2);


                detailMain.appendChild(Slider);
                document.body.appendChild(detailMain);


                //detailMain.id="main";
                // document.body.appendChild(detailMain);
                // var newDiv = document.createElement("div");
                // newDiv.className="rowDiv";
                // detailMain.appendChild(newDiv);
                // var detailDiv = this

                // detailDiv.id="detailDiv";
                

                // detailDiv.appendChild(purchaseDate);

                // this.appendChild(purchaseDate);

                // newDiv.appendChild(detailDiv);
                // newDiv.appendChild(br);

                // detailMain.appendChild(newDiv);
                // //detailMain.appendChild(br);


                // var sellBtn = document.createElement("BUTTON");
                // var relatedBtn = document.createElement("BUTTON");
                // relatedBtn.onclick = function(){alert("Feature Coming Soon!");}
                // sellBtn.onclick = function(){alert("Feature Coming Soon!");}



                // sellBtn.innerHTML = "Sell Item";
                // relatedBtn.innerHTML = "Shop Similar Items";

                // detailMain.appendChild(sellBtn);
                // detailMain.appendChild(relatedBtn);
                // var nav = document.getElementById("nav");
                //nav.src = "x.png";

                nav.onclick = function(){location.reload();}


                

                
            }

            
            var brandName = document.createElement("h2");
            var clothColor = document.createElement("h2");
            var usagePerItem = document.createElement("h2")
           
            var br = document.createElement("br");
            var br2 = document.createElement("br");
            var br3 = document.createElement("br");

            clothColor.innerHTML = "Color: " + shirts[i].color;
            brandName.innerHTML = "Brand: " + shirts[i].brand;
            
            usagePerItem.innerHTML = "Time On: " + ConvertUsage(shirts[i].usage);
            // div.className="container"
            var pic = document.createElement("img")
            pic.className="rowImg"
            pic.src = shirts[i].pic;
            //div.innerHTML = shirts[i].brand + " " + shirts[i].color; 
            div.appendChild(pic);
            div.appendChild(br);
            div.appendChild(clothColor);
            div.appendChild(br2)
            div.appendChild(brandName);
            div.appendChild(br3);
            div.appendChild(usagePerItem);


            rowDiv.appendChild(div);
            

        }
    


}


function goBack() {
  window.history.back();
}
 function ConvertUsage(num){
      let h = Math.floor(num/60);
      let m = num%60;
      let d = Math.floor(h/24);
      h = h%24;                     
      return(d +" days " + h +" hours " + m + " minutes ").toString();
    }
function sortArrayHigh(){
    //console.log(shirts);


    shirts.sort(function(a, b){
    return b.usage-a.usage})

    console.log(shirts);
}
function sortArrayLow(){
    //console.log(shirts);


    shirts.sort(function(a, b){
    return a.usage-b.usage})

    console.log(shirts);
}
