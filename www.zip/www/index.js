var shirt1 = {color: "red", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt2 = {color: "blue", brand:"polo", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt3 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt4 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt5 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt6 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt7 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt8 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt9 = {color: "red", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt10 = {color: "blue", brand:"polo", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt11 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt12 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt13 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt14 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt15 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt16 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt17 = {color: "red", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt18 = {color: "blue", brand:"polo", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt19 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt20 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt21 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt22 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
var shirt23 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};
 var shirt24 = {color: "green", brand:"nike", style: "tshirt", usage: 500, purchaseDate: 1/1/19,
 pic: "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"};

var shirts = [shirt1,shirt2,shirt3,shirt4,shirt5,


shirt6,shirt7,
shirt8,shirt9,shirt10,shirt11,shirt12,shirt13,shirt14,shirt15,
shirt16,shirt17,shirt18,shirt19,shirt20,shirt21,shirt22,shirt23,shirt24];

var rows = 0;

var n = 0;

function NumberOfRows(shirtArray) {
	n = shirtArray.length + 1;
	if (shirtArray.length % 3 === 0) {
		rows = shirts.length/3;
	}
	if(n % 3 === 0){
		rows = n/3;
	}
	else if((n+1) % 3 === 0){
		rows = (n+1)/3;
	}
	return rows;

}


function createList() {
	var outputMain = document.createElement("main")
	document.body.appendChild(outputMain);
	//outputMain.className="tab";

	NumberOfRows(shirts);

	for (var j = 0; j <= rows; j++) {
		var rowDiv = document.createElement("div");
		rowDiv.className="rowDiv";
		outputMain.appendChild(rowDiv);

	
		for (var i = 0; i <= shirts.length; i++) {
		
			var div = document.createElement("div");
			div.className="overRightDiv";
			var brandName = document.createElement("h2");
			var clothColor = document.createElement("h2");
			var br = document.createElement("br");
			var br2 = document.createElement("br");

			clothColor.innerHTML = "Color: " + shirts[i].color;
			brandName.innerHTML = "Brand: " + shirts[i].brand;
			// div.className="container"
			var pic = document.createElement("img")
			pic.className="rowImg"
			pic.src = "https://www.rlmedia.io/is/image/PoloGSI/s7-1323313_lifestyle?$rl_506_630$"
  			//div.innerHTML = shirts[i].brand + " " + shirts[i].color; 
  			div.appendChild(pic);
  			div.appendChild(br2);
  			div.appendChild(clothColor);
  			div.appendChild(br)
  			div.appendChild(brandName);



  			rowDiv.appendChild(div);

		}
	}

}


function goBack() {
  window.history.back();
}

// tabs and camera plugin logic


"use strict";

/*===========================*/
/* put global variables here */
/*===========================*/

var takePhotoButton
var photoStatus    
var photoImage     
var cameraOptions  
var imageFilename
var options 
var homeTab  
var filterTab    

/* wait until all phonegap/cordova is loaded then call onDeviceReady*/
document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady(){

    StatusBar.overlaysWebView(false); // force ios to show status bar
    navigator.splashscreen.show();
	showHomeTab();



    takePhotoButton = document.getElementById('takePhotoButtonId')
    photoStatus     = document.getElementById('photoStatusId')
    photoImage      = document.getElementById('photoImageId')
    imageFilename   = document.getElementById('imageFilenameId')
    cameraOptions   = document.getElementById('cameraOptionsId')
    filterTab       = document.getElementById('filterTab')
    homeTab         = document.getElementById("homeTab")

    options         = {
            quality: 40,
            destinationType:    Camera.DestinationType.FILE_URI,
            sourceType:         Camera.PictureSourceType.CAMERA,
            correctOrientation: true, 
            mediaType:          Camera.MediaType.PICTURE,
            encodingType:       Camera.EncodingType.JPEG,
            cameraDirection:    Camera.Direction.BACK,
            targetWidth:        300,
            targetHeight:       400        
    }

    cameraOptions.innerHTML = JSON.stringify(options, null, 2)
    filterTab.style.display = "none";
}

function takePhoto() {
    navigator.camera.getPicture(photoSuccess, photoError, options)
}

function photoSuccess(imageURI) {
    photoStatus.innerHTML = "Success!";
    imageFilename.innerHTML = imageURI;
    photoImage.src = imageURI
}

function photoError(errorMessage) {
    photoStatus.innerHTML = "Failed: " + errorMessage;
    imageFilename.innerHTML = "";
}

function showHomeTab() {
	document.getElementById('home').click();
}

function showTab(event, tabName) {
    // Declare all variables
    var i, tabContentElems, tabLinkElems;

    // Get all elements with class="tabContent" and hide them
    tabContentElems = document.getElementsByClassName("tabContent");
    for (i = 0; i < tabContentElems.length; i++) {
        tabContentElems[i].style.display = "none";
    }

    // Get all elements with class="tabLink" and remove class "active"
    tabLinkElems = document.getElementsByClassName("tabLink");
    for (i = 0; i < tabLinkElems.length; i++) {
        tabLinkElems[i].className = 
        	tabLinkElems[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the link
    document.getElementById(tabName).style.display = "block";
    event.currentTarget.className += " active";
}

function filter() {
    // if(homeTab.style.display == "block")
    // {
    //   homeTab.style.display = "none";
    //   filterTab.style.display = "block"
    // }
    // else
    // {
    // homeTab.style.display = "block"
    // filterTab.style.display = "none"
    // }
    



}